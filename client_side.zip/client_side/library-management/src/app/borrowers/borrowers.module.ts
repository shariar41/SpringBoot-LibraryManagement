import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BorrowersRoutingModule } from './borrowers-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BorrowersRoutingModule
  ]
})
export class BorrowersModule { }
