import { Component } from '@angular/core';

@Component({
  selector: 'app-author-list',
  standalone: true,
  imports: [],
  templateUrl: './author-list.component.html',
  styleUrl: './author-list.component.css'
})
export class AuthorListComponent {

}
