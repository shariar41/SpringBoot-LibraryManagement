import { Component } from '@angular/core';

@Component({
  selector: 'app-add-author',
  standalone: true,
  imports: [],
  templateUrl: './add-author.component.html',
  styleUrl: './add-author.component.css'
})
export class AddAuthorComponent {

}
