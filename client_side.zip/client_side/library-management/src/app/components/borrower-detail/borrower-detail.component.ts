import { Component } from '@angular/core';

@Component({
  selector: 'app-borrower-detail',
  standalone: true,
  imports: [],
  templateUrl: './borrower-detail.component.html',
  styleUrl: './borrower-detail.component.css'
})
export class BorrowerDetailComponent {

}
